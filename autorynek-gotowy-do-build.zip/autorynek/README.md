# Auto Rynek (mod Fabric, Minecraft 1.21.11, tylko klient)

## Jak uzywac
1. Wejdz na serwer, nacisnij **N** (zmienisz klawisz w Opcje -> Sterowanie).
2. Wypelnij okno, np. dla serc:
   - Nazwa itemu: `serce`            (kolory ignorowane, wielkosc liter tez)
   - Maks. koszt oferty: `70k`       (porownywany z linia "Koszt $80k ($80,000)" z opisu itemu)
   - Min. ilosc w ofercie: `64`      (tylko stacki)
   - Cena wystawienia: `90k`         (0 = nie wystawiaj po zakupie)
   - Ilosc w /wystaw: `1`            (0 = caly stack z reki)
   - Komenda rynku: `rynek`          (ta, ktora otwiera okno "Rynek (1/386)")
3. Kliknij **START**. Mod sam otwiera rynek, szuka oferty, klika LEWYM (zakup),
   po zakupie bierze item do reki i wpisuje `/wystaw <ilosc> <cena>`.
   **STOP** zatrzymuje. Status widac na dole okna.

## Zaawansowane (plik `config/autorynek.json` w folderze gry)
- `sellCommand` - szablon komendy wystawienia, domyslnie `wystaw {ilosc} {cena}`
- `marketTitle` - fragment tytulu okna rynku (domyslnie `Rynek`)
- `maxPages` + `nextPageName` - ile stron przeszukiwac i jak nazywa sie przycisk "nastepna strona"
- `confirmWord` - fragment nazwy przycisku potwierdzenia zakupu, jesli serwer pyta o potwierdzenie
- `delayMs`, `refreshMs`, `buyWaitMs`, `afterSellMs` - przerwy (nie schodz za nisko, bo serwer moze Cie wyrzucic za spam)

## Budowanie
Potrzebujesz: JDK 21 oraz Gradle 9.x (albo IntelliJ IDEA - otworz folder jako projekt Gradle, sam pobierze Gradle).
    gradle build
Gotowy mod: `build/libs/autorynek-1.0.0.jar` -> wrzuc do `mods/` razem z **Fabric API**.

## Jesli build zglosi blad (tego kodu nie dalo sie skompilowac przy pisaniu)
- *Nie znaleziono yarn / fabric-api / loader*: w `gradle.properties` wpisz aktualne wersje z https://fabricmc.net/develop
- `KeyBinding.Category.MISC` nie istnieje: w `AutoRynekClient` zamien ostatni argument na `"category.autorynek"` (starszy zapis z tekstem)
- `getSelectedSlot` / `setSelectedSlot` nie istnieje: w `Bot.sell` uzyj `inv.selectedSlot` (pole) zamiast metod
- Inne bledy z nazwami klas: wklej mi tekst bledu, poprawie.

## Uwaga
Automatyczne kupowanie i wystawianie to makro. Wiele serwerow zabrania takich modow - sprawdz regulamin,
bo mozesz dostac bana.
