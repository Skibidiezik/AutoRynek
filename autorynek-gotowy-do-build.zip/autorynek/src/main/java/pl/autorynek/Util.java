package pl.autorynek;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Util {
    private Util() {}

    private static final Pattern COLOR = Pattern.compile("[&§][0-9a-fk-orA-FK-OR]");

    /** Usuwa kody kolorow (&a, §l itd.). */
    public static String strip(String s) {
        return s == null ? "" : COLOR.matcher(s).replaceAll("");
    }

    /** Czy nazwa itemu zawiera wpisany fragment (bez kolorow i bez wielkosci liter). */
    public static boolean nameMatches(ItemStack stack, String query) {
        if (stack.isEmpty()) return false;
        String q = strip(query).toLowerCase().trim();
        if (q.isEmpty()) return false;
        String n = strip(stack.getName().getString()).toLowerCase();
        return n.contains(q);
    }

    public static List<String> lore(ItemStack stack) {
        List<String> out = new ArrayList<>();
        LoreComponent lore = stack.get(DataComponentTypes.LORE);
        if (lore != null) {
            for (Text t : lore.lines()) out.add(strip(t.getString()));
        }
        return out;
    }

    /** Wyciaga koszt z linii typu: "Koszt $80k ($80,000)". Zwraca -1, gdy nie znaleziono. */
    public static long priceFromLore(ItemStack stack) {
        Pattern exact = Pattern.compile("\\(\\$\\s*([0-9][0-9.,]*)\\)");
        Pattern loose = Pattern.compile("\\$\\s*([0-9][0-9.,]*\\s*[kKmMbB]?)");
        for (String line : lore(stack)) {
            if (!line.toLowerCase().contains("koszt")) continue;
            Matcher m = exact.matcher(line);
            if (m.find()) {
                long v = parseMoney(m.group(1));
                if (v > 0) return v;
            }
            m = loose.matcher(line);
            if (m.find()) {
                long v = parseMoney(m.group(1));
                if (v > 0) return v;
            }
        }
        return -1;
    }

    /** "70k" -> 70000, "1.5m" -> 1500000, "80,000" -> 80000, "1,5m" -> 1500000. */
    public static long parseMoney(String raw) {
        if (raw == null) return 0;
        String s = raw.replace("$", "").replace(" ", "").trim().toLowerCase();
        if (s.isEmpty()) return 0;
        double mul = 1;
        char last = s.charAt(s.length() - 1);
        if (last == 'k') { mul = 1_000; s = s.substring(0, s.length() - 1); }
        else if (last == 'm') { mul = 1_000_000; s = s.substring(0, s.length() - 1); }
        else if (last == 'b') { mul = 1_000_000_000; s = s.substring(0, s.length() - 1); }
        if (s.indexOf(',') >= 0 && s.indexOf('.') < 0) {
            int digitsAfter = s.length() - s.lastIndexOf(',') - 1;
            s = digitsAfter < 3 ? s.replace(',', '.') : s.replace(",", "");
        } else {
            s = s.replace(",", "");
        }
        try {
            return Math.round(Double.parseDouble(s) * mul);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static String formatMoney(long v) {
        return String.format("%,d", v).replace(',', ' ');
    }
}
