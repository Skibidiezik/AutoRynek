package pl.autorynek;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Okno otwierane klawiszem N. */
public class ConfigScreen extends Screen {
    private final List<TextFieldWidget> fields = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();

    private TextFieldWidget fName, fMax, fMin, fSell, fSellAmount, fMaxBuys, fCmd;
    private ButtonWidget startButton;

    public ConfigScreen() {
        super(Text.literal("Auto Rynek"));
    }

    private TextFieldWidget add(String label, String value, int x, int y, int w) {
        TextFieldWidget f = new TextFieldWidget(this.textRenderer, x, y, w, 18, Text.literal(label));
        f.setMaxLength(100);
        f.setText(value);
        fields.add(f);
        labels.add(label);
        this.addDrawableChild(f);
        return f;
    }

    @Override
    protected void init() {
        fields.clear();
        labels.clear();
        Config c = Config.get();
        int w = 240;
        int x = this.width / 2 - w / 2;
        int y = 36;
        int step = 34;

        fName = add("Nazwa itemu (kolory ignorowane, np. serce)", c.itemName, x, y, w); y += step;
        fMax = add("Maks. koszt oferty (np. 70k, 1.5m)", c.maxPrice > 0 ? String.valueOf(c.maxPrice) : "", x, y, w); y += step;
        fMin = add("Min. ilosc w ofercie (64 = tylko stacki)", String.valueOf(c.minAmount), x, y, w); y += step;
        fSell = add("Cena wystawienia po zakupie (0 = nie wystawiaj)", c.sellPrice > 0 ? String.valueOf(c.sellPrice) : "0", x, y, w); y += step;
        fSellAmount = add("Ilosc w /wystaw (0 = caly stack)", String.valueOf(c.sellAmount), x, y, w); y += step;
        fMaxBuys = add("Zatrzymaj po tylu zakupach (0 = bez limitu)", String.valueOf(c.maxBuys), x, y, w); y += step;
        fCmd = add("Komenda rynku (bez ukosnika)", c.marketCommand, x, y, w); y += step;

        startButton = ButtonWidget.builder(Text.literal(Bot.running ? "STOP" : "START"), b -> {
            saveFields();
            if (Bot.running) {
                Bot.stop("Zatrzymany");
            } else {
                Bot.start();
            }
            startButton.setMessage(Text.literal(Bot.running ? "STOP" : "START"));
        }).dimensions(x, y, 118, 20).build();
        this.addDrawableChild(startButton);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Zapisz i zamknij"), b -> this.close())
                .dimensions(x + 122, y, 118, 20).build());
    }

    private void saveFields() {
        Config c = Config.get();
        c.itemName = fName.getText().trim();
        c.maxPrice = Util.parseMoney(fMax.getText());
        c.minAmount = (int) Math.max(1, Util.parseMoney(fMin.getText()));
        c.sellPrice = Util.parseMoney(fSell.getText());
        c.sellAmount = (int) Math.max(0, Util.parseMoney(fSellAmount.getText()));
        c.maxBuys = (int) Math.max(0, Util.parseMoney(fMaxBuys.getText()));
        String cmd = fCmd.getText().trim();
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        c.marketCommand = cmd.isEmpty() ? "rynek" : cmd;
        Config.save();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawTextWithShadow(this.textRenderer, Text.literal("Auto Rynek"), this.width / 2 - 30, 12, 0xFFFFFF);
        for (int i = 0; i < fields.size(); i++) {
            TextFieldWidget f = fields.get(i);
            context.drawTextWithShadow(this.textRenderer, Text.literal(labels.get(i)), f.getX(), f.getY() - 10, 0xA0A0A0);
        }
        String st = "Status: " + Bot.status + "  |  kupiono: " + Bot.bought;
        context.drawTextWithShadow(this.textRenderer, Text.literal(st), this.width / 2 - 120, this.height - 20, 0x55FF55);
    }

    @Override
    public void close() {
        saveFields();
        super.close();
    }
}
