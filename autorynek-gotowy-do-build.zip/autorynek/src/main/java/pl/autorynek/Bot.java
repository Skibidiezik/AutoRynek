package pl.autorynek;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayList;
import java.util.List;

/** Logika automatu: otwiera rynek, kupuje pasujace oferty, wystawia kupiony item. */
public final class Bot {
    private Bot() {}

    private enum State { SEARCH, WAIT_PURCHASE, SELL }

    public static boolean running = false;
    public static int bought = 0;
    public static String status = "Zatrzymany";

    private static State state = State.SEARCH;
    private static long nextAction = 0;
    private static long lastOpen = 0;
    private static long waitUntil = 0;
    private static int page = 0;
    private static int countBefore = 0;

    public static void start() {
        running = true;
        bought = 0;
        state = State.SEARCH;
        page = 0;
        nextAction = 0;
        lastOpen = 0;
        status = "Szukam...";
    }

    public static void stop(String why) {
        running = false;
        status = why;
    }

    public static void tick(MinecraftClient mc) {
        if (!running) return;
        if (mc.player == null || mc.interactionManager == null) {
            stop("Zatrzymany (brak gracza)");
            return;
        }
        long now = System.currentTimeMillis();
        if (now < nextAction) return;
        Config c = Config.get();
        if (c.itemName == null || c.itemName.isBlank() || c.maxPrice <= 0) {
            stop("Ustaw nazwe itemu i cene kupna");
            return;
        }
        switch (state) {
            case SEARCH -> search(mc, c, now);
            case WAIT_PURCHASE -> waitPurchase(mc, c, now);
            case SELL -> sell(mc, c, now);
        }
    }

    // ---------------- okno rynku ----------------

    private static boolean isMarket(MinecraftClient mc, Config c) {
        if (mc.currentScreen instanceof HandledScreen<?> hs) {
            String t = Util.strip(hs.getTitle().getString()).toLowerCase();
            return t.contains(c.marketTitle.toLowerCase());
        }
        return false;
    }

    /** Sloty okna (bez ekwipunku gracza). */
    private static List<Slot> containerSlots(MinecraftClient mc, ScreenHandler handler) {
        List<Slot> out = new ArrayList<>();
        for (Slot s : handler.slots) {
            if (!(s.inventory instanceof PlayerInventory)) out.add(s);
        }
        return out;
    }

    private static void click(MinecraftClient mc, ScreenHandler handler, int slotId, int button, SlotActionType type) {
        mc.interactionManager.clickSlot(handler.syncId, slotId, button, type, mc.player);
    }

    private static void search(MinecraftClient mc, Config c, long now) {
        if (!isMarket(mc, c)) {
            // jesli jest otwarte inne okno (np. potwierdzenie), niech dalej dziala ten sam mechanizm potwierdzania
            if (mc.currentScreen instanceof HandledScreen<?> other) {
                if (tryConfirm(mc, c, other)) { nextAction = now + c.delayMs; return; }
            }
            if (now - lastOpen > c.refreshMs) {
                if (mc.currentScreen != null) mc.player.closeHandledScreen();
                mc.player.networkHandler.sendChatCommand(c.marketCommand);
                lastOpen = now;
                page = 0;
                status = "Otwieram rynek...";
            }
            nextAction = now + c.delayMs;
            return;
        }
        HandledScreen<?> hs = (HandledScreen<?>) mc.currentScreen;
        ScreenHandler handler = hs.getScreenHandler();
        List<Slot> slots = containerSlots(mc, handler);

        // 1) szukamy oferty
        for (Slot s : slots) {
            ItemStack st = s.getStack();
            if (!Util.nameMatches(st, c.itemName)) continue;
            if (st.getCount() < Math.max(1, c.minAmount)) continue;
            long price = Util.priceFromLore(st);
            if (price <= 0 || price > c.maxPrice) continue;
            countBefore = countInInventory(mc, c.itemName);
            click(mc, handler, s.id, 0, SlotActionType.PICKUP);
            state = State.WAIT_PURCHASE;
            waitUntil = now + c.buyWaitMs;
            nextAction = now + c.delayMs;
            status = "Kupuje: " + st.getCount() + "x za $" + Util.formatMoney(price);
            return;
        }

        // 2) nastepna strona
        if (page + 1 < Math.max(1, c.maxPages)) {
            String want = Util.strip(c.nextPageName).toLowerCase();
            for (Slot s : slots) {
                ItemStack st = s.getStack();
                if (st.isEmpty()) continue;
                if (Util.strip(st.getName().getString()).toLowerCase().contains(want)) {
                    click(mc, handler, s.id, 0, SlotActionType.PICKUP);
                    page++;
                    nextAction = now + c.delayMs;
                    status = "Strona " + (page + 1) + "...";
                    return;
                }
            }
        }

        // 3) nic nie ma - zamykamy i odswiezamy po chwili
        mc.player.closeHandledScreen();
        page = 0;
        lastOpen = now;
        nextAction = now + c.refreshMs;
        status = "Brak ofert - odswiezam...";
    }

    /** Jesli rynek pyta o potwierdzenie zakupu, klika przycisk z nazwa zawierajaca confirmWord. */
    private static boolean tryConfirm(MinecraftClient mc, Config c, HandledScreen<?> hs) {
        String word = Util.strip(c.confirmWord).toLowerCase();
        if (word.isEmpty()) return false;
        ScreenHandler handler = hs.getScreenHandler();
        for (Slot s : containerSlots(mc, handler)) {
            ItemStack st = s.getStack();
            if (st.isEmpty()) continue;
            if (Util.strip(st.getName().getString()).toLowerCase().contains(word)) {
                click(mc, handler, s.id, 0, SlotActionType.PICKUP);
                return true;
            }
        }
        return false;
    }

    // ---------------- po kliknieciu "kup" ----------------

    private static void waitPurchase(MinecraftClient mc, Config c, long now) {
        if (mc.currentScreen instanceof HandledScreen<?> hs && !isMarket(mc, c)) {
            if (tryConfirm(mc, c, hs)) { nextAction = now + c.delayMs; return; }
        }
        int now_count = countInInventory(mc, c.itemName);
        if (now_count > countBefore) {
            bought++;
            if (mc.currentScreen != null) mc.player.closeHandledScreen();
            status = "Kupiono (lacznie: " + bought + ")";
            if (c.maxBuys > 0 && bought >= c.maxBuys) {
                if (c.sellPrice > 0) { state = State.SELL; nextAction = now + 400; waitUntil = 1; return; }
                stop("Koniec - kupiono " + bought);
                return;
            }
            if (c.sellPrice > 0) {
                state = State.SELL;
                waitUntil = 0;
                nextAction = now + 400;
            } else {
                state = State.SEARCH;
                nextAction = now + c.delayMs;
            }
            return;
        }
        if (now > waitUntil) {
            // zakup sie nie udal (ktos byl szybszy / brak kasy) - wracamy do szukania
            status = "Zakup sie nie udal - szukam dalej";
            state = State.SEARCH;
            nextAction = now + c.delayMs;
        }
    }

    // ---------------- wystawianie ----------------

    private static void sell(MinecraftClient mc, Config c, long now) {
        PlayerEntity p = mc.player;
        PlayerInventory inv = p.getInventory();
        if (mc.currentScreen != null) {
            mc.player.closeHandledScreen();
            nextAction = now + 300;
            return;
        }
        // czy kupiony item jest juz w rece?
        ItemStack hand = p.getMainHandStack();
        if (!Util.nameMatches(hand, c.itemName)) {
            int found = -1;
            for (int i = 0; i < inv.size(); i++) {
                if (Util.nameMatches(inv.getStack(i), c.itemName)) { found = i; if (i < 9) break; }
            }
            if (found < 0) {
                status = "Nie widze kupionego itemu";
                finishSell(c, now);
                return;
            }
            int selected = inv.getSelectedSlot();
            if (found < 9) {
                inv.setSelectedSlot(found);
            } else {
                // przenosimy item z ekwipunku na aktualnie wybrany slot paska
                click(mc, p.playerScreenHandler, found, selected, SlotActionType.SWAP);
            }
            nextAction = now + 350;
            return;
        }
        int amount = c.sellAmount > 0 ? Math.min(c.sellAmount, hand.getCount()) : hand.getCount();
        String cmd = c.sellCommand
                .replace("{ilosc}", String.valueOf(amount))
                .replace("{cena}", String.valueOf(c.sellPrice));
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        mc.player.networkHandler.sendChatCommand(cmd);
        status = "Wystawiono: /" + cmd;
        finishSell(c, now);
    }

    private static void finishSell(Config c, long now) {
        if (c.maxBuys > 0 && bought >= c.maxBuys) {
            stop("Koniec - kupiono " + bought);
            return;
        }
        state = State.SEARCH;
        nextAction = now + c.afterSellMs;
        lastOpen = 0;
    }

    // ---------------- pomocnicze ----------------

    private static int countInInventory(MinecraftClient mc, String name) {
        int n = 0;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (Util.nameMatches(st, name)) n += st.getCount();
        }
        return n;
    }
}
