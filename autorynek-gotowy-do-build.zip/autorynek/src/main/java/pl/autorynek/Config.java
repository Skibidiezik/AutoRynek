package pl.autorynek;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Ustawienia moda, zapisywane w config/autorynek.json */
public class Config {
    // --- ustawiane w oknie pod klawiszem N ---
    public String itemName = "";          // fragment nazwy itemu (kolory sa ignorowane)
    public long maxPrice = 0;             // maksymalny KOSZT oferty (taki, jaki widac w "Koszt $..."), np. 70000
    public int minAmount = 1;             // minimalna ilosc w ofercie (np. 64 = cale stacki)
    public long sellPrice = 0;            // za ile wystawic po zakupie (0 = nie wystawiaj)
    public int sellAmount = 1;            // ilosc w komendzie wystawienia (0 = caly stack z reki)
    public int maxBuys = 0;               // po ilu zakupach sie zatrzymac (0 = bez limitu)
    public String marketCommand = "rynek";            // komenda otwierajaca rynek (bez ukosnika)

    // --- zaawansowane (tylko w pliku json) ---
    public String sellCommand = "wystaw {ilosc} {cena}"; // szablon komendy wystawienia (bez ukosnika)
    public String marketTitle = "Rynek";                  // fragment tytulu okna rynku
    public String nextPageName = "Następna";              // fragment nazwy przycisku nastepnej strony
    public int maxPages = 1;                              // ile stron przeszukiwac (1 = tylko pierwsza)
    public String confirmWord = "potwierd";               // fragment nazwy przycisku potwierdzenia zakupu (jesli rynek pyta)
    public int delayMs = 600;                             // przerwa miedzy akcjami
    public int refreshMs = 2500;                          // jak czesto odswiezac rynek, gdy nic nie znaleziono
    public int buyWaitMs = 2500;                          // ile czekac na potwierdzenie zakupu
    public int afterSellMs = 1200;                        // przerwa po wystawieniu

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config instance;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("autorynek.json");
    }

    public static Config get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                instance = GSON.fromJson(Files.readString(p), Config.class);
            }
        } catch (Exception ignored) {
        }
        if (instance == null) instance = new Config();
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(get()));
        } catch (IOException ignored) {
        }
    }
}
